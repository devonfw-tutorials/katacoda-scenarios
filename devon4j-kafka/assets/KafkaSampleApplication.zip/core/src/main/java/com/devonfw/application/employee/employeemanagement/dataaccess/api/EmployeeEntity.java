package com.devonfw.application.employee.employeemanagement.dataaccess.api;

import javax.persistence.Entity;
import javax.persistence.Table;

import com.devonfw.application.employee.employeemanagement.common.api.Employee;
import com.devonfw.application.employee.general.dataaccess.api.ApplicationPersistenceEntity;

@Entity
@Table(name = "Employee")
public class EmployeeEntity extends ApplicationPersistenceEntity implements Employee {

  private String name;

  private Integer age;

  private String location;

  private static final long serialVersionUID = 1L;

  /**
   * @return name
   */
  public String getName() {

    return this.name;
  }

  /**
   * @param name new value of {@link #getname}.
   */
  public void setName(String name) {

    this.name = name;
  }

  /**
   * @return age
   */
  public Integer getAge() {

    return this.age;
  }

  /**
   * @param age new value of {@link #getage}.
   */
  public void setAge(Integer age) {

    this.age = age;
  }

  /**
   * @return location
   */
  public String getLocation() {

    return this.location;
  }

  /**
   * @param location new value of {@link #getlocation}.
   */
  public void setLocation(String location) {

    this.location = location;
  }

}
