package com.devonfw.application.employee.employeemanagement.service.impl.rest;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.awaitility.Awaitility;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.devonfw.application.employee.employeemanagement.logic.api.to.EmployeeEto;
import com.devonfw.application.employee.employeemanagement.logic.api.to.EmployeeSearchCriteriaTo;
import com.devonfw.application.employee.employeemanagement.service.api.rest.EmployeemanagementRestService;
import com.devonfw.application.employee.general.service.base.test.RestServiceTest;
import com.devonfw.module.service.common.api.client.config.ServiceClientConfigBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author jgunther
 *
 */
public class KafkaDemoServiceTest extends RestServiceTest {

  /** Logger instance. */
  private static final Logger LOG = LoggerFactory.getLogger(KafkaDemoServiceTest.class);

  @Test
  public void saveAndDeleteEmployeeViaKafkaService() {

    // Step 1: Add new employee via Kafka
    // Arrange
    EmployeeEto employee = new EmployeeEto();
    employee.setAge(24);
    employee.setLocation("Germany");
    employee.setName("Julian");

    String convertedMessage = null;
    try {
      convertedMessage = new ObjectMapper().writer().writeValueAsString(employee);
    } catch (JsonProcessingException e) {
      LOG.error("Error while converting employee as String");
    }

    ProducerRecord<String, String> producerRecord = new ProducerRecord<>("employeeapp-employee-v1-add",
        convertedMessage);

    EmployeemanagementRestService employeemanagementRestService = getServiceClientFactory()
        .create(EmployeemanagementRestService.class, new ServiceClientConfigBuilder().host("localhost").authBasic()
            .userLogin("admin").userPassword("admin").buildMap());

    // Act
    getMessageSender().sendMessage(producerRecord);

    // Assert
    EmployeeSearchCriteriaTo employeCriteria = new EmployeeSearchCriteriaTo();
    employeCriteria.setName(employee.getName());
    employeCriteria.setLocation(employee.getLocation());

    Awaitility.await()
        .until(() -> employeemanagementRestService.findEmployees(employeCriteria).getTotalElements() == 1);

    assert (employeemanagementRestService.findEmployees(employeCriteria).getTotalElements() == 1);

    // Step 2: Delete employee via Kafka
    // Arrange
    EmployeeEto newEmployee = employeemanagementRestService.findEmployees(employeCriteria).getContent().get(0);

    producerRecord = new ProducerRecord<>("employeeapp-employee-v1-delete", newEmployee.getId().toString());

    // Act
    getMessageSender().sendMessage(producerRecord);
    // Assert
    Awaitility.await().until(() -> employeemanagementRestService.findEmployees(employeCriteria).isEmpty() == true);

    assert (employeemanagementRestService.findEmployees(employeCriteria).isEmpty() == true);
  }
}
