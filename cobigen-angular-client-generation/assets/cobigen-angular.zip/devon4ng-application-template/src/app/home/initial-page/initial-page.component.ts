import { Component } from '@angular/core';

@Component({
  selector: 'public-initial-page',
  templateUrl: './initial-page.component.html',
  styleUrls: ['./initial-page.component.scss'],
})
export class InitialPageComponent {}
