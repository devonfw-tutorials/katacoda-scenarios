export interface Sort {
  direction: String;
  property: String;
}
