/*tslint:disable*/
export let logoColor: string = `

`;
